import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import type { ChartCalculation } from "@shared/astrology";
import { degreesToZodiac } from "@shared/astrology";

type Props = {
  birthInfo: {
    birthDate: string;
    birthTime: string;
    birthPlace: string;
    latitude: string;
    longitude: string;
  };
};

export function NatalChart({ birthInfo }: Props) {
  const [chartData, setChartData] = useState<ChartCalculation | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchChartData() {
      try {
        const response = await fetch("/api/calculate-chart", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(birthInfo),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || "Failed to calculate chart");
        }

        const data = await response.json();
        setChartData(data);
        setError(null);
      } catch (error) {
        console.error("Error calculating chart:", error);
        setError(error instanceof Error ? error.message : "Failed to calculate chart");
      }
    }

    if (birthInfo.birthDate && birthInfo.birthTime && birthInfo.birthPlace) {
      fetchChartData();
    }
  }, [birthInfo]);

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="aspect-square rounded-full border-4 border-primary/20 p-8 relative">
          {error ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-destructive">{error}</p>
            </div>
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">Birth Details</h3>
                <p className="text-sm text-muted-foreground">
                  {new Date(birthInfo.birthDate).toLocaleDateString()}
                </p>
                <p className="text-sm text-muted-foreground">{birthInfo.birthTime}</p>
                <p className="text-sm text-muted-foreground">
                  {birthInfo.birthPlace}
                </p>

                {chartData && (
                  <div className="mt-4 space-y-2">
                    <p className="text-sm font-medium">
                      Ascendant: {degreesToZodiac(chartData.ascendant).sign} {degreesToZodiac(chartData.ascendant).degree}°
                    </p>
                    <p className="text-sm font-medium">
                      Midheaven: {degreesToZodiac(chartData.midheaven).sign} {degreesToZodiac(chartData.midheaven).degree}°
                    </p>
                    <div className="mt-4">
                      <h4 className="text-sm font-semibold mb-2">Planetary Positions</h4>
                      {chartData.planets.map((planet) => (
                        <p key={planet.name} className="text-sm">
                          {planet.name}: {degreesToZodiac(planet.longitude).sign} {degreesToZodiac(planet.longitude).degree}°
                        </p>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}