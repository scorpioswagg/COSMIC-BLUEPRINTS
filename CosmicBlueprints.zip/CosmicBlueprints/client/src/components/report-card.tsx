import { Link } from "wouter";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { type Report } from "@shared/schema";
import { formatPrice } from "@/lib/reports";
import { REPORT_DESCRIPTIONS } from "@/lib/reports";

type Props = {
  report: Report;
};

export function ReportCard({ report }: Props) {
  return (
    <Card className="overflow-hidden">
      <div className="grid md:grid-cols-3 gap-6">
        <div
          className="h-48 md:h-full bg-cover bg-center"
          style={{ backgroundImage: `url(${report.previewUrl})` }}
        />
        <div className="md:col-span-2 p-6">
          <h3 className="text-2xl font-semibold mb-2">{report.title}</h3>
          <p className="text-muted-foreground mb-4">{report.description}</p>
          <p className="text-lg font-bold mb-6">{formatPrice(report.price)}</p>
          
          <div className="flex gap-4">
            <Button asChild>
              <Link href={`/checkout/${report.id}`}>Purchase Report</Link>
            </Button>
            <Button variant="outline">Preview Sample</Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
