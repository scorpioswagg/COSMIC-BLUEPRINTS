import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBirthInfoSchema, type InsertBirthInfo } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

type Props = {
  onSubmit: (data: InsertBirthInfo) => void;
  isLoading?: boolean;
};

export function BirthInfoForm({ onSubmit, isLoading }: Props) {
  const { toast } = useToast();
  const [isGeocodingLoading, setIsGeocodingLoading] = useState(false);

  const form = useForm<InsertBirthInfo>({
    resolver: zodResolver(insertBirthInfoSchema),
    defaultValues: {
      name: "",
      birthDate: "",
      birthTime: "12:00",
      birthPlace: "",
      latitude: "",
      longitude: "",
    },
  });

  const getCoordinates = async (place: string): Promise<{ lat: string; lon: string } | null> => {
    try {
      const response = await fetch(
        `https://api.geoapify.com/v1/geocode/search?text=${encodeURIComponent(place)}&format=json&apiKey=bb6c7c3cc1994d5ab0f32ed7fbe54f34`
      );
      const data = await response.json();

      if (data.results && data.results.length > 0) {
        const { lat, lon } = data.results[0];
        return { lat: lat.toString(), lon: lon.toString() };
      }
      return null;
    } catch (error) {
      console.error('Geocoding error:', error);
      return null;
    }
  };

  const handleSubmit = async (data: InsertBirthInfo) => {
    setIsGeocodingLoading(true);
    try {
      // Get coordinates for the birth place
      const coordinates = await getCoordinates(data.birthPlace);
      if (!coordinates) {
        throw new Error("Could not determine location coordinates. Please check the birth place.");
      }

      // Prepare the complete data with coordinates and formatted date
      const formattedData = {
        ...data,
        birthDate: new Date(data.birthDate).toISOString(),
        latitude: coordinates.lat,
        longitude: coordinates.lon,
      };

      await onSubmit(formattedData);
    } catch (error) {
      console.error('Submit error:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save birth information",
        variant: "destructive",
      });
    } finally {
      setIsGeocodingLoading(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Full Name</FormLabel>
              <FormControl>
                <Input {...field} placeholder="John Doe" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="birthDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Birth Date</FormLabel>
              <FormControl>
                <Input 
                  type="date" 
                  {...field}
                  max={new Date().toISOString().split('T')[0]}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="birthTime"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Birth Time (24-hour format)</FormLabel>
              <FormControl>
                <Input type="time" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="birthPlace"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Birth Place</FormLabel>
              <FormControl>
                <Input 
                  {...field} 
                  placeholder="City, Country"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={isLoading || isGeocodingLoading}>
          {isLoading || isGeocodingLoading ? "Processing..." : "Generate Natal Chart"}
        </Button>
      </form>
    </Form>
  );
}