
import React from "react";
import { cn } from "@/lib/utils";

interface PageContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  fullWidth?: boolean;
}

export function PageContainer({
  children,
  className,
  fullWidth = false,
  ...props
}: PageContainerProps) {
  return (
    <div
      className={cn(
        "min-h-screen flex flex-col",
        fullWidth ? "px-4" : "container py-8",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}
