
import React from "react";
import { cn } from "@/lib/utils";

interface HeaderProps extends React.HTMLAttributes<HTMLElement> {
  title?: string;
}

export function Header({ title = "Application", className, ...props }: HeaderProps) {
  return (
    <header
      className={cn(
        "w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
        className
      )}
      {...props}
    >
      <div className="container flex h-16 items-center">
        <div className="mr-4 flex">
          <a href="/" className="flex items-center space-x-2">
            <span className="font-bold text-xl">{title}</span>
          </a>
        </div>
        <nav className="flex flex-1 items-center justify-end space-x-4">
          {/* Add navigation links here as needed */}
        </nav>
      </div>
    </header>
  );
}
