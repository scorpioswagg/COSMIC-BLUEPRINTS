import { Link } from "wouter";
import { GiStarsStack } from "react-icons/gi";

export function NavHeader() {
  return (
    <header className="bg-background border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-xl font-bold">
          <GiStarsStack className="h-6 w-6" />
          <span>Cosmic Blueprints</span>
        </Link>
        
        <nav>
          <ul className="flex gap-6">
            <li>
              <Link href="/reports" className="hover:text-primary">
                Reports
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
