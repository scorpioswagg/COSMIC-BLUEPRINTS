import type { Report } from "@shared/schema";

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(price / 100);
}

export const REPORT_DESCRIPTIONS: Record<string, string> = {
  natal: "Your complete birth chart analysis reveals the cosmic blueprint of your life path.",
  personality: "Understand your core traits and tendencies through planetary placements.",
  purpose: "Discover your soul's mission and life direction through astrological wisdom.",
  relationships: "Explore relationship dynamics and compatibility through synastry analysis.",
  career: "Uncover your professional strengths and ideal career paths through astrological guidance.",
  yearly: "Get a detailed forecast of your year ahead with planetary transits and progressions.",
  monthly: "Receive monthly predictions and timing for important life decisions.",
  transits: "Understand how current planetary positions are affecting your life now.",
  solar_return: "Annual forecast based on the Sun's return to its natal position.",
  lunar_return: "Monthly emotional and intuitive guidance based on lunar cycles.",
  children: "Parenting insights and understanding your child's potential through astrology.",
  health: "Astrological insights into health tendencies and wellness optimization."
};