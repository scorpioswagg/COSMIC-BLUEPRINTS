import { useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Elements } from "@stripe/react-stripe-js";
import { stripePromise, createPaymentIntent } from "@/lib/stripe";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { type Report } from "@shared/schema";
import { formatPrice } from "@/lib/reports";

export default function Checkout() {
  const { reportId } = useParams();
  const [isGift, setIsGift] = useState(false);
  const [clientSecret, setClientSecret] = useState<string>();

  const { data: report, isLoading } = useQuery<Report>({
    queryKey: [`/api/reports/${reportId}`],
  });

  const initializePayment = async () => {
    if (report) {
      const { clientSecret } = await createPaymentIntent(report.id);
      setClientSecret(clientSecret);
    }
  };

  if (isLoading || !report) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Skeleton className="h-96 max-w-2xl mx-auto" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>

        <Card className="mb-8">
          <CardContent className="pt-6">
            <h2 className="text-xl font-semibold mb-4">{report.title}</h2>
            <p className="text-muted-foreground mb-4">{report.description}</p>
            <p className="text-2xl font-bold">{formatPrice(report.price)}</p>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <Label htmlFor="gift">Send as a gift?</Label>
              <Switch
                id="gift"
                checked={isGift}
                onCheckedChange={setIsGift}
              />
            </div>

            {isGift && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="giftEmail">Recipient's Email</Label>
                  <Input id="giftEmail" type="email" />
                </div>
                <div>
                  <Label htmlFor="giftMessage">Gift Message</Label>
                  <Textarea id="giftMessage" />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {clientSecret && (
          <Elements stripe={stripePromise} options={{ clientSecret }}>
            {/* Stripe Payment Element would go here */}
          </Elements>
        )}
      </div>
    </div>
  );
}
