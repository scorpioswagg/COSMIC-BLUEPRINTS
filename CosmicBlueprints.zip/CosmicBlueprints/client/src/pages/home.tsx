import { useState } from "react";
import { useLocation } from "wouter";
import { BirthInfoForm } from "@/components/birth-info-form";
import { NatalChart } from "@/components/natal-chart";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { InsertBirthInfo } from "@shared/schema";

export default function Home() {
  const [, navigate] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [birthInfo, setBirthInfo] = useState<InsertBirthInfo | null>(null);
  const { toast } = useToast();

  const handleSubmit = async (data: InsertBirthInfo) => {
    setIsLoading(true);
    try {
      const res = await apiRequest("POST", "/api/birth-info", data);
      const savedBirthInfo = await res.json();
      setBirthInfo(data); // Store the birth info for the chart
      toast({
        title: "Success!",
        description: "Your birth information has been saved.",
      });
    } catch (error) {
      console.error('Submit error:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save birth information",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative">
      {/* Hero Section */}
      <div
        className="h-[500px] bg-cover bg-center"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(https://images.unsplash.com/photo-1464802686167-b939a6910659)",
        }}
      >
        <div className="container mx-auto px-4 h-full flex items-center">
          <div className="max-w-2xl text-white">
            <h1 className="text-5xl font-bold mb-6">
              Discover Your Cosmic Blueprint
            </h1>
            <p className="text-xl mb-8">
              Unlock the secrets written in the stars at your birth and navigate
              your life path with confidence.
            </p>
          </div>
        </div>
      </div>

      {/* Birth Info Form and Chart Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-xl mx-auto">
          <div className="bg-card rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-semibold mb-6 text-center">
              Enter Your Birth Information
            </h2>
            <BirthInfoForm onSubmit={handleSubmit} isLoading={isLoading} />
          </div>

          {birthInfo && (
            <div className="mt-8">
              <h2 className="text-2xl font-semibold mb-6 text-center">
                Your Natal Chart
              </h2>
              <NatalChart birthInfo={birthInfo} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}