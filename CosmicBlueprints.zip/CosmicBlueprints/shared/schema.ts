import { pgTable, text, serial, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const birthInfo = pgTable("birth_info", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  birthDate: timestamp("birth_date").notNull(),
  birthTime: text("birth_time").notNull(),
  birthPlace: text("birth_place").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
});

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // in cents
  previewUrl: text("preview_url"),
  type: text("type").notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  birthInfoId: integer("birth_info_id").notNull(),
  reportId: integer("report_id").notNull(),
  stripePaymentId: text("stripe_payment_id"),
  status: text("status").notNull(), // pending, completed, failed
  isGift: boolean("is_gift").default(false),
  giftEmail: text("gift_email"),
  giftMessage: text("gift_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Custom validation for the birth date
const birthDateSchema = z.string().refine((val) => {
  const date = new Date(val);
  return !isNaN(date.getTime());
}, "Invalid date format");

export const insertBirthInfoSchema = createInsertSchema(birthInfo)
  .omit({ id: true })
  .extend({
    name: z.string().min(2, "Name must be at least 2 characters"),
    birthDate: birthDateSchema,
    birthTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format (use HH:mm)"),
    birthPlace: z.string().min(2, "Birth place must be at least 2 characters"),
    latitude: z.string().regex(/^-?([0-8]?[0-9]|90)(\.[0-9]+)?$/, "Invalid latitude (-90 to 90)"),
    longitude: z.string().regex(/^-?([0-9]{1,2}|1[0-7][0-9]|180)(\.[0-9]+)?$/, "Invalid longitude (-180 to 180)"),
  });

export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, createdAt: true });

export type InsertBirthInfo = z.infer<typeof insertBirthInfoSchema>;
export type BirthInfo = typeof birthInfo.$inferSelect;
export type Report = typeof reports.$inferSelect;
export type Order = typeof orders.$inferSelect;

export const giftOrderSchema = z.object({
  isGift: z.boolean(),
  giftEmail: z.string().email().optional(),
  giftMessage: z.string().max(500).optional(),
});