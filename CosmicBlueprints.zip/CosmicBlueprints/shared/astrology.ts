import { BirthInfo } from "./schema";

// Astronomical constants
const EARTH_RADIUS = 6371; // km
const J2000 = 2451545.0; // Julian date for epoch 2000.0

export type CelestialBody = {
  name: string;
  longitude: number;  // Celestial longitude in degrees
  latitude: number;   // Celestial latitude in degrees
  distance: number;   // Distance in astronomical units
  speed: number;      // Daily motion in degrees
};

export type House = {
  number: number;
  cusp: number;      // Degree of the house cusp
  sign: string;      // Zodiac sign of the house cusp
};

export type Aspect = {
  body1: string;
  body2: string;
  type: string;      // conjunction, opposition, trine, etc.
  orb: number;       // Deviation from exact aspect in degrees
  applying: boolean; // Whether the aspect is applying or separating
};

export type ChartCalculation = {
  ascendant: number;
  midheaven: number;
  houses: House[];
  planets: CelestialBody[];
  aspects: Aspect[];
};

// Calculate Julian Date from a JavaScript Date object
export function getJulianDate(date: Date): number {
  const time = date.getTime() / 86400000 + 2440587.5;
  return time;
}

// Convert decimal degrees to zodiac position
export function degreesToZodiac(degrees: number): { sign: string; degree: number } {
  const signs = [
    "Aries", "Taurus", "Gemini", "Cancer", 
    "Leo", "Virgo", "Libra", "Scorpio", 
    "Sagittarius", "Capricorn", "Aquarius", "Pisces"
  ];
  
  const normalizedDeg = degrees % 360;
  const signIndex = Math.floor(normalizedDeg / 30);
  const degree = normalizedDeg % 30;
  
  return {
    sign: signs[signIndex],
    degree: parseFloat(degree.toFixed(2))
  };
}

// Calculate aspect between two celestial bodies
export function calculateAspect(body1: CelestialBody, body2: CelestialBody): Aspect | null {
  const aspects = [
    { type: "conjunction", angle: 0, orb: 10 },
    { type: "opposition", angle: 180, orb: 10 },
    { type: "trine", angle: 120, orb: 8 },
    { type: "square", angle: 90, orb: 8 },
    { type: "sextile", angle: 60, orb: 6 }
  ];

  const angle = Math.abs(body1.longitude - body2.longitude) % 360;
  
  for (const aspect of aspects) {
    const diff = Math.abs(angle - aspect.angle);
    if (diff <= aspect.orb) {
      return {
        body1: body1.name,
        body2: body2.name,
        type: aspect.type,
        orb: parseFloat(diff.toFixed(2)),
        applying: body1.speed > body2.speed
      };
    }
  }
  
  return null;
}

// Main function to calculate chart details
export async function calculateChart(birthInfo: BirthInfo): Promise<ChartCalculation> {
  // This is a placeholder implementation that will be expanded
  // with actual astronomical calculations
  
  const jd = getJulianDate(birthInfo.birthDate);
  
  // For now, return some sample data
  // This will be replaced with actual calculations
  return {
    ascendant: 0,
    midheaven: 90,
    houses: Array.from({ length: 12 }, (_, i) => ({
      number: i + 1,
      cusp: i * 30,
      sign: degreesToZodiac(i * 30).sign
    })),
    planets: [
      {
        name: "Sun",
        longitude: 0,
        latitude: 0,
        distance: 1,
        speed: 0.9856
      },
      // Add more planets here
    ],
    aspects: []
  };
}
