import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertBirthInfoSchema, insertOrderSchema, giftOrderSchema } from "@shared/schema";
import Stripe from "stripe";
import { calculateChart } from "@shared/astrology";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY is required");
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-02-24.acacia",
});

export async function registerRoutes(app: Express) {
  const httpServer = createServer(app);

  // Get all reports
  app.get("/api/reports", async (_req, res) => {
    const reports = await storage.getReports();
    res.json(reports);
  });

  // Create birth info
  app.post("/api/birth-info", async (req, res) => {
    const result = insertBirthInfoSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    const birthInfo = await storage.createBirthInfo(result.data);
    res.json(birthInfo);
  });

  // Create Stripe payment intent
  app.post("/api/create-payment-intent", async (req, res) => {
    const { reportId } = req.body;
    const report = await storage.getReport(reportId);

    if (!report) {
      return res.status(404).json({ error: "Report not found" });
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: report.price,
      currency: "usd",
    });

    res.json({ clientSecret: paymentIntent.client_secret });
  });

  // Create order
  app.post("/api/orders", async (req, res) => {
    const orderData = req.body;

    // Validate gift info if present
    if (orderData.isGift) {
      const giftResult = giftOrderSchema.safeParse(orderData);
      if (!giftResult.success) {
        return res.status(400).json({ error: giftResult.error });
      }
    }

    const result = insertOrderSchema.safeParse(orderData);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    // Ensure isGift is a boolean if present
    const order = await storage.createOrder({
      ...result.data,
      isGift: result.data.isGift ?? false
    });
    res.json(order);
  });

  // Calculate chart
  app.post("/api/calculate-chart", async (req, res) => {
    try {
      const birthInfo = req.body;
      // Convert string date to Date object
      birthInfo.birthDate = new Date(birthInfo.birthDate);

      const chartData = await calculateChart(birthInfo);
      res.json(chartData);
    } catch (error) {
      console.error("Chart calculation error:", error);
      res.status(500).json({ error: "Failed to calculate chart" });
    }
  });

  return httpServer;
}