import { BirthInfo, Report, Order, InsertBirthInfo } from "@shared/schema";

export interface IStorage {
  // Birth Info
  createBirthInfo(info: InsertBirthInfo): Promise<BirthInfo>;
  getBirthInfo(id: number): Promise<BirthInfo | undefined>;

  // Reports
  getReports(): Promise<Report[]>;
  getReport(id: number): Promise<Report | undefined>;

  // Orders
  createOrder(order: Omit<Order, "id" | "createdAt">): Promise<Order>;
  getOrder(id: number): Promise<Order | undefined>;
  updateOrderStatus(id: number, status: string): Promise<Order>;
}

export class MemStorage implements IStorage {
  private birthInfos: Map<number, BirthInfo>;
  private reports: Map<number, Report>;
  private orders: Map<number, Order>;
  private currentIds: { [key: string]: number };

  constructor() {
    this.birthInfos = new Map();
    this.reports = new Map();
    this.orders = new Map();
    this.currentIds = { birthInfo: 1, report: 1, order: 1 };

    // Seed reports
    const sampleReports: Report[] = [
      {
        id: this.currentIds.report++,
        title: "Complete Natal Chart Analysis",
        description: "In-depth analysis of your birth chart including all planetary positions and aspects.",
        price: 2999,
        previewUrl: "https://images.unsplash.com/photo-1464802686167-b939a6910659",
        type: "natal"
      },
      {
        id: this.currentIds.report++,
        title: "Personality Profile",
        description: "Detailed exploration of your personality traits based on your astrological placements.",
        price: 1999,
        previewUrl: "https://images.unsplash.com/photo-1504221507732-5246c045949b",
        type: "personality"
      },
      {
        id: this.currentIds.report++,
        title: "Life Path & Purpose",
        description: "Discover your life's purpose and potential career paths through astrological guidance.",
        price: 2499,
        previewUrl: "https://images.unsplash.com/photo-1503416997304-7f8bf166c121",
        type: "purpose"
      },
      {
        id: this.currentIds.report++,
        title: "Relationship Compatibility",
        description: "Deep dive into relationship dynamics and partner compatibility through synastry analysis.",
        price: 3499,
        previewUrl: "https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2",
        type: "relationships"
      },
      {
        id: this.currentIds.report++,
        title: "Career & Vocational Guidance",
        description: "Comprehensive career analysis and timing for professional decisions.",
        price: 2799,
        previewUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40",
        type: "career"
      },
      {
        id: this.currentIds.report++,
        title: "Yearly Forecast",
        description: "Detailed 12-month forecast with key dates and opportunities.",
        price: 3999,
        previewUrl: "https://images.unsplash.com/photo-1435777940218-be0b632d06db",
        type: "yearly"
      },
      {
        id: this.currentIds.report++,
        title: "Monthly Forecast",
        description: "Detailed 30-day prediction with daily highlights and guidance.",
        price: 1499,
        previewUrl: "https://images.unsplash.com/photo-1507089947368-19c1da9775ae",
        type: "monthly"
      },
      {
        id: this.currentIds.report++,
        title: "Current Transits Analysis",
        description: "Understanding how current planetary positions affect your life.",
        price: 1999,
        previewUrl: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa",
        type: "transits"
      },
      {
        id: this.currentIds.report++,
        title: "Solar Return Report",
        description: "Your personal year ahead based on your solar return chart.",
        price: 2499,
        previewUrl: "https://images.unsplash.com/photo-1532693322450-2cb5c511067d",
        type: "solar_return"
      },
      {
        id: this.currentIds.report++,
        title: "Lunar Return Report",
        description: "Monthly emotional forecast based on lunar returns.",
        price: 1799,
        previewUrl: "https://images.unsplash.com/photo-1532767153582-b1a0e5145009",
        type: "lunar_return"
      },
      {
        id: this.currentIds.report++,
        title: "Children & Parenting",
        description: "Understanding your child's potential and parenting guidance.",
        price: 2699,
        previewUrl: "https://images.unsplash.com/photo-1516627145497-ae6968895b74",
        type: "children"
      },
      {
        id: this.currentIds.report++,
        title: "Health & Wellness",
        description: "Astrological insights for optimizing your health and well-being.",
        price: 2299,
        previewUrl: "https://images.unsplash.com/photo-1506126613408-eca07ce68773",
        type: "health"
      }
    ];

    sampleReports.forEach(report => this.reports.set(report.id, report));
  }

  async createBirthInfo(info: InsertBirthInfo): Promise<BirthInfo> {
    const id = this.currentIds.birthInfo++;
    const birthInfo = {
      ...info,
      id,
      birthDate: new Date(info.birthDate) // Ensure we're creating a new Date object
    };
    this.birthInfos.set(id, birthInfo);
    return birthInfo;
  }

  async getBirthInfo(id: number): Promise<BirthInfo | undefined> {
    return this.birthInfos.get(id);
  }

  async getReports(): Promise<Report[]> {
    return Array.from(this.reports.values());
  }

  async getReport(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }

  async createOrder(order: Omit<Order, "id" | "createdAt">): Promise<Order> {
    const id = this.currentIds.order++;
    const newOrder = {
      ...order,
      id,
      createdAt: new Date(),
      isGift: order.isGift ?? false,
      giftEmail: order.giftEmail ?? null,
      giftMessage: order.giftMessage ?? null,
      stripePaymentId: order.stripePaymentId ?? null
    };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    const order = this.orders.get(id);
    if (!order) throw new Error("Order not found");
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
}

export const storage = new MemStorage();